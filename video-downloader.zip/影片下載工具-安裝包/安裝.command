#!/bin/zsh
# 影片資料工具 — 一鍵安裝
# 用法：對這個檔案按右鍵 → 打開（第一次會有安全性警告，選「打開」即可）

set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
ARCH=$(uname -m)
BIN="$HOME/bin"
APPD="$HOME/bin/vdl-app"
FFD="$HOME/bin/vdl-ffmpeg"
NODED="$HOME/bin/vdl-node"

echo ""
echo "════════════════════════════════"
echo "  影片資料工具 安裝程式"
echo "  機型: $ARCH"
echo "════════════════════════════════"
echo ""

mkdir -p "$BIN" "$APPD" "$FFD" "$HOME/Applications"

echo "[1/4] 下載 yt-dlp 引擎（約 36MB）…"
curl -# -L -o "$BIN/yt-dlp" "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos"
chmod +x "$BIN/yt-dlp"

echo "[2/4] 下載 ffmpeg（約 40MB）…"
if [[ "$ARCH" == "arm64" ]]; then FZ="darwin_arm64.zip"; else FZ="darwin.zip"; fi
curl -# -L -o "/tmp/vdl-ff.zip" "https://github.com/zackees/ffmpeg_bins/raw/main/v8.0/$FZ"
ditto -x -k "/tmp/vdl-ff.zip" "$FFD"
# 若解壓出子資料夾，把執行檔攤平到 FFD
if [[ ! -f "$FFD/ffmpeg" ]]; then
  find "$FFD" -type f \( -name ffmpeg -o -name ffprobe \) -exec mv {} "$FFD/" \;
fi
chmod +x "$FFD/ffmpeg" "$FFD/ffprobe"
rm -f /tmp/vdl-ff.zip

# 一律使用安裝包自帶的 Node：系統裝的 node（如 Homebrew）在 App 啟動環境裡看不到
if [[ -x "$NODED/bin/node" ]]; then
  echo "[3/4] Node 已存在，略過"
else
  echo "[3/4] 下載 Node 執行環境（約 50MB）…"
  if [[ "$ARCH" == "arm64" ]]; then NT="darwin-arm64"; else NT="darwin-x64"; fi
  curl -# -L -o "/tmp/vdl-node.tgz" "https://nodejs.org/dist/v22.12.0/node-v22.12.0-$NT.tar.gz"
  mkdir -p "$NODED"
  tar -xzf /tmp/vdl-node.tgz -C "$NODED" --strip-components=1
  rm -f /tmp/vdl-node.tgz
fi

echo "[4/4] 安裝程式與 App…"
cp "$SRC/payload/server.js" "$SRC/payload/index.html" "$SRC/payload/start.sh" "$APPD/"
chmod +x "$APPD/start.sh"
osacompile -o "$HOME/Applications/影片下載.app" "$SRC/payload/app.applescript"

echo ""
echo "✅ 安裝完成！"
echo ""
echo "App 位置：家目錄 → Applications → 影片下載"
echo "（建議拖到 Dock 方便使用）"
echo ""
open -R "$HOME/Applications/影片下載.app"
read "?按 Enter 關閉…"
