#!/bin/zsh
# 影片資料工具 — 一鍵安裝
# 用法：對這個檔案按右鍵 → 打開（第一次會有安全性警告，選「打開」即可）

set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
ARCH=$(uname -m)
BIN="$HOME/bin"
APPD="$HOME/bin/vdl-app"
FFD="$HOME/bin/vdl-ffmpeg"
NODED="$HOME/bin/vdl-node"

echo ""
echo "════════════════════════════════"
echo "  影片資料工具 安裝程式"
echo "  機型: $ARCH"
echo "════════════════════════════════"
echo ""

mkdir -p "$BIN" "$APPD" "$FFD" "$HOME/Applications"
# 暫存一律放自己的隨機資料夾（不用共用 /tmp 的固定檔名，免得被別人先放檔替換）
TMPD="$(mktemp -d)"; trap 'rm -rf "$TMPD"' EXIT
# 下載的 ffmpeg／Node 鎖版本並驗 sha256；對不上就停，不裝來路不明的執行檔
verify() { echo "$2  $1" | shasum -a 256 -c - >/dev/null 2>&1 || { echo "❌ $1 檢查碼不符，安裝中止（可能下載不完整或被竄改）"; exit 1; }; }

echo "[1/4] 下載 yt-dlp 引擎（約 36MB）…"
curl -# -L -o "$BIN/yt-dlp" "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos"
chmod +x "$BIN/yt-dlp"

echo "[2/4] 下載 ffmpeg（約 40MB）…"
FFC="df95abcb0ce6efff710dda5ef28a2f6f1dc21493"   # 2026-10-02 鎖定的 commit
if [[ "$ARCH" == "arm64" ]]; then FZ="darwin_arm64.zip"; FS="b2da44a8169c4d09a97db996250690c3346f72e4795521d23d3dbb1e72421207"
else FZ="darwin.zip"; FS="70fd5b21cb37b6ea97c8b584cf76b3cc6a90179831c9c269811b9716c28605fb"; fi
curl -# -L -o "$TMPD/vdl-ff.zip" "https://github.com/zackees/ffmpeg_bins/raw/$FFC/v8.0/$FZ"
verify "$TMPD/vdl-ff.zip" "$FS"
ditto -x -k "$TMPD/vdl-ff.zip" "$FFD"
# 若解壓出子資料夾，把執行檔攤平到 FFD
if [[ ! -f "$FFD/ffmpeg" ]]; then
  find "$FFD" -type f \( -name ffmpeg -o -name ffprobe \) -exec mv {} "$FFD/" \;
fi
chmod +x "$FFD/ffmpeg" "$FFD/ffprobe"

# 一律使用安裝包自帶的 Node：系統裝的 node（如 Homebrew）在 App 啟動環境裡看不到
if [[ -x "$NODED/bin/node" ]]; then
  echo "[3/4] Node 已存在，略過"
else
  echo "[3/4] 下載 Node 執行環境（約 50MB）…"
  if [[ "$ARCH" == "arm64" ]]; then NT="darwin-arm64"; NS="293dcc6c2408da21562d135b0412525e381bb6fe150d688edb58fe850d0f3e13"
  else NT="darwin-x64"; NS="52bc25dd026db7247c3c00439afdb83e95087248267f02d6c1a7250d1f896173"; fi
  curl -# -L -o "$TMPD/vdl-node.tgz" "https://nodejs.org/dist/v22.12.0/node-v22.12.0-$NT.tar.gz"
  verify "$TMPD/vdl-node.tgz" "$NS"
  mkdir -p "$NODED"
  tar -xzf "$TMPD/vdl-node.tgz" -C "$NODED" --strip-components=1
fi

echo "[4/4] 安裝程式與 App…"
cp "$SRC/payload/server.js" "$SRC/payload/index.html" "$SRC/payload/start.sh" "$APPD/"
chmod +x "$APPD/start.sh"
osacompile -o "$HOME/Applications/影片下載.app" "$SRC/payload/app.applescript"

echo ""
echo "✅ 安裝完成！"
echo ""
echo "App 位置：家目錄 → Applications → 影片下載"
echo "（建議拖到 Dock 方便使用）"
echo ""
open -R "$HOME/Applications/影片下載.app"
read "?按 Enter 關閉…"
