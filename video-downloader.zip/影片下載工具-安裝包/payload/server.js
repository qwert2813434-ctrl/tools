// 影片資料工具 — 本機伺服器（零依賴，Node 內建模組）
// 由 ~/Applications/影片下載.app 啟動；介面: http://127.0.0.1:47831
const http = require('http');
const https = require('https');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

const HOME = os.homedir();
const PORT = 47831;
const YTDLP = path.join(HOME, 'bin/yt-dlp');
// ffmpeg 位置：安裝包版
const FFDIR = [
  path.join(HOME, 'bin/vdl-ffmpeg'),
].find(d => fs.existsSync(path.join(d, 'ffmpeg')));
if (!FFDIR) { console.error('找不到 ffmpeg，請重跑安裝'); process.exit(1); }
const FFMPEG = path.join(FFDIR, 'ffmpeg');
const FFPROBE = path.join(FFDIR, 'ffprobe');
const OUT = path.join(HOME, 'Downloads/影片下載');
const GIFOUT = path.join(OUT, 'GIF');
const DATA = path.join(HOME, 'Library/Application Support/vdl-app');
const HIST = path.join(DATA, 'history.json');
const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36';

// 讓 yt-dlp 的 --js-runtimes node 找得到 node（用啟動本伺服器的同一顆），並補上安裝包版 node
process.env.PATH = path.dirname(process.execPath) + ':' +
                   path.join(HOME, 'bin/vdl-node/bin') + ':' + process.env.PATH;

for (const d of [OUT, GIFOUT, DATA]) fs.mkdirSync(d, { recursive: true });

// ---------- 紀錄 ----------
function loadHist() { try { return JSON.parse(fs.readFileSync(HIST, 'utf8')); } catch { return []; } }
function addHist(entry) {
  const h = loadHist();
  h.unshift({ time: new Date().toISOString(), ...entry });
  fs.writeFileSync(HIST, JSON.stringify(h.slice(0, 300), null, 1));
}

// ---------- 站別規則（與 ~/bin/vdl 同步維護）----------
function siteArgs(url) {
  // 比對網域本身，不比對整串網址（?instagram.com 這種也會中，會讓 yt-dlp 讀進整個 Chrome cookie）
  let host = ''; try { host = new URL(url).hostname; } catch {}
  const on = d => host === d || host.endsWith('.' + d);
  if (on('xpccdn.com')) {
    // 新片场的影片檔 CDN（貓抓等擴充抓到的直連）：驗 Referer＋Range（播放器特徵），不用 cookies
    return ['--referer', 'https://www.xinpianchang.com/', '--user-agent', UA,
            '--add-headers', 'Range:bytes=0-'];
  }
  if (on('xinpianchang.com')) {
    return ['--cookies-from-browser', 'chrome', '--impersonate', 'chrome',
            '--user-agent', UA, '--referer', 'https://www.xinpianchang.com/'];
  }
  if (on('instagram.com')) {
    // IG 擋未登入的請求：借 Chrome 的登入狀態
    return ['--cookies-from-browser', 'chrome', '--user-agent', UA];
  }
  return [];
}
function isTvcf(url) { try { return /(^|\.)tvcf\.co\.kr$/.test(new URL(url).hostname); } catch { return false; } }

// ---------- 安全（2026-10-02）----------
// 這台伺服器開在本機，任何網頁都敲得到。外面送來的網址、檔案路徑一律當陌生人的資料。
function isWebUrl(u) {
  try { const x = new URL(String(u)); return x.protocol === 'http:' || x.protocol === 'https:'; } catch { return false; }
}
// 檔案只准在下載資料夾裡（擋 ../、絕對路徑、ffmpeg 的 concat:／http: 這類協定）
function inOut(file) {
  if (typeof file !== 'string' || !file) return null;
  const f = path.resolve(file);
  if (!f.startsWith(OUT + path.sep) || !fs.existsSync(f)) return null;
  return fs.realpathSync(f).startsWith(fs.realpathSync(OUT) + path.sep) ? f : null;
}
const OK_HOSTS = ['127.0.0.1:' + PORT, 'localhost:' + PORT];
const OK_ORIGINS = ['http://127.0.0.1:' + PORT, 'http://localhost:' + PORT];

function fetchPage(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': UA } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return resolve(fetchPage(new URL(res.headers.location, url).href));
      }
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
    req.setTimeout(20000, () => { req.destroy(); reject(new Error('timeout')); });
  });
}

async function probeTvcf(url) {
  const { status, body } = await fetchPage(url);
  if (status !== 200) throw new Error('TVCF 頁面回應 ' + status);
  const streams = [...new Set(body.match(/https:\/\/wowza\.tvcf\.co\.kr:\d+[^"\s\\]*playlist\.m3u8/g) || [])];
  if (!streams.length) throw new Error('這頁找不到影片串流');
  const best = streams.find(s => s.includes('_720p')) || streams.find(s => !s.includes('_i.mp4')) || streams[0];
  const tm = body.match(/<meta property="og:title" content="([^"]*)"/);
  const title = ((tm ? tm[1] : 'tvcf').replace(/ \| TVCF/, '') + '_' + url.split('/').pop()).replace(/[/\\:]/g, '-');
  return { url, title, kind: 'tvcf', stream: best,
           heights: [{ h: 720, label: '720p（該站最高）' }], audio: true };
}

function runJson(args, timeoutMs = 60000) {
  return new Promise((resolve, reject) => {
    const p = spawn(YTDLP, args);
    let out = '', err = '';
    p.stdout.on('data', d => out += d);
    p.stderr.on('data', d => err += d);
    const t = setTimeout(() => { p.kill(); reject(new Error('probe timeout')); }, timeoutMs);
    p.on('close', code => {
      clearTimeout(t);
      if (code === 0) { try { resolve(JSON.parse(out)); } catch (e) { reject(e); } }
      else reject(new Error(err.split('\n').filter(l => l.includes('ERROR')).join('\n') || ('exit ' + code)));
    });
  });
}

async function probeGeneric(url) {
  const info = await runJson(['-J', '--no-playlist', '--js-runtimes', 'node', ...siteArgs(url), '--', url], 90000);
  const fmts = info.formats || [];
  const bestAudio = fmts.filter(f => f.acodec && f.acodec !== 'none')
                        .reduce((a, f) => Math.max(a, f.filesize || f.filesize_approx || 0), 0);
  const byH = {};
  for (const f of fmts) {
    if (!f.height || !f.vcodec || f.vcodec === 'none') continue;
    const sz = f.filesize || f.filesize_approx || 0;
    if (!byH[f.height] || sz > byH[f.height]) byH[f.height] = sz;
  }
  const heights = Object.keys(byH).map(Number).sort((a, b) => b - a).slice(0, 6)
    .map(h => {
      const total = byH[h] ? byH[h] + bestAudio : 0;
      return { h, label: h + 'p' + (total ? ` (~${(total / 1048576).toFixed(0)}MB)` : '') };
    });

  // 新片场的頁面通行證是一次性的：下載時若再敲一次頁面就會 406。
  // 檢查階段已經解到影音合一的直連檔，這裡存起來，下載時直接用。
  const direct = {};
  if (url.includes('xinpianchang.com')) {
    for (const f of fmts) {
      if (!f.url || !f.height) continue;
      if (!f.vcodec || f.vcodec === 'none' || !f.acodec || f.acodec === 'none') continue;
      const sz = f.filesize || f.filesize_approx || 0;
      if (!direct[f.height] || sz > direct[f.height].size) direct[f.height] = { url: f.url, size: sz };
    }
  }

  return { url, title: info.title || url, kind: 'generic',
           duration: info.duration || 0,
           heights: heights.length ? heights : [{ h: 1080, label: '自動（最佳）' }],
           audio: true,
           direct: Object.keys(direct).length ? direct : undefined };
}

// 從檢查階段存下的直連挑一條：要求的畫質 → 往下找最接近的 → 再不然最高的
function pickDirect(direct, height) {
  if (!direct) return null;
  const hs = Object.keys(direct).map(Number).sort((a, b) => b - a);
  if (!hs.length) return null;
  const want = height || hs[0];
  const h = hs.find(x => x <= want) ?? hs[hs.length - 1];
  return direct[h].url;
}

// ---------- 任務 ----------
const jobs = {};
let jobSeq = 1;

function newJob(type, title) {
  const id = String(jobSeq++);
  jobs[id] = { id, type, title, progress: 0, status: 'running', file: null, log: [] };
  return jobs[id];
}
function jobLog(job, line) {
  line = line.trim();
  if (!line) return;
  job.log.push(line);
  if (job.log.length > 40) job.log.shift();
}

function startDownload(item, height, audioOnly) {
  const directUrl0 = pickDirect(item && item.direct, height);
  const target0 = item && (item.kind === 'tvcf' ? item.stream : (directUrl0 || item.url));
  if (!item || !isWebUrl(item.url) || !isWebUrl(target0)) throw new Error('只收 http／https 網址');
  const job = newJob(audioOnly ? '音訊' : `影片 ${height ? height + 'p' : ''}`, item.title);
  const pathFile = path.join(DATA, 'job' + job.id + '.path');
  let args = ['--ffmpeg-location', FFDIR, '--js-runtimes', 'node',
              '--no-playlist', '--embed-metadata', '--newline', '--progress',
              '--print-to-file', 'after_move:filepath', pathFile];
  let target;
  const directUrl = pickDirect(item.direct, height);
  if (item.kind === 'tvcf') {
    const safe = String(item.title || 'tvcf').replace(/[/\\:*?"<>|]/g, '-').replace(/^\.+/, '').slice(0, 100) || 'tvcf';
    args.push('--referer', 'https://www.tvcf.co.kr/',
              '-o', path.join(OUT, safe + '.%(ext)s'));
    target = item.stream;
  } else if (directUrl) {
    // 用檢查階段存下的直連檔（新片场）：不再回頭敲頁面，也順便留住正確標題
    const safe = String(item.title || 'video').replace(/[/\\:*?"<>|]/g, '-').slice(0, 100);
    args.push(...siteArgs(directUrl), '-o', path.join(OUT, safe + '.%(ext)s'));
    target = directUrl;
  } else {
    args.push(...siteArgs(item.url), '-o', path.join(OUT, '%(title).120B.%(ext)s'));
    target = item.url;
  }
  if (audioOnly) {
    args.push('-f', 'ba/b', '-x', '--audio-format', 'mp3');
  } else if (directUrl) {
    args.push('--merge-output-format', 'mp4');   // 直連檔本身就是選定畫質，不再做格式篩選
  } else {
    const h = height || 1080;
    args.push('-f', `bv*[height<=${h}]+ba/b[height<=${h}]/b`, '--merge-output-format', 'mp4');
  }
  args.push('--', target);   // -- 之後一律當網址，擋「網址」其實是 --config-locations 這類參數

  const p = spawn(YTDLP, args);
  const onData = d => {
    for (const line of d.toString().split('\n')) {
      const m = line.match(/\[download\]\s+([\d.]+)%/);
      if (m) job.progress = parseFloat(m[1]);
      else jobLog(job, line);
    }
  };
  p.stdout.on('data', onData);
  p.stderr.on('data', onData);
  p.on('close', code => {
    if (code === 0) {
      job.status = 'done'; job.progress = 100;
      try { job.file = fs.readFileSync(pathFile, 'utf8').trim().split('\n').pop(); } catch {}
      try { fs.unlinkSync(pathFile); } catch {}
      addHist({ type: job.type, title: job.title, url: item.url, file: job.file, status: 'ok' });
    } else {
      job.status = 'error';
      job.error = job.log.filter(l => l.includes('ERROR')).join('\n') || job.log.slice(-8).join('\n');
      if (/xinpianchang|xpccdn/.test(item.url) && /403|406/.test(job.error))
        job.error += '\n\n提示：新片场的連結有時效（幾小時）。請重按一次「檢查連結」拿新的，再下載。';
      addHist({ type: job.type, title: job.title, url: item.url, status: 'error', error: job.error });
    }
  });
  return job;
}

// ---------- GIF ----------
function ffprobeDuration(file) {
  return new Promise((resolve) => {
    const p = spawn(FFPROBE, ['-v', 'quiet', '-print_format', 'json', '-show_format', file]);
    let out = '';
    p.stdout.on('data', d => out += d);
    p.on('close', () => {
      try { resolve(parseFloat(JSON.parse(out).format.duration) || 0); } catch { resolve(0); }
    });
  });
}

function gifArgs(file, outFile, width, fps, start, dur) {
  // 這幾個值會拼進 ffmpeg 濾鏡字串：一律轉成有範圍的數字，擋濾鏡注入
  const num = (v, lo, hi, d) => { const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
  width = Math.round(num(width, 16, 4096, 480)); fps = Math.round(num(fps, 1, 60, 12));
  start = num(start, 0, 86400, 0); dur = num(dur, 0, 86400, 0);
  const vf = `[0:v]fps=${fps},scale=${width}:-2:flags=lanczos,split[a][b];[a]palettegen=stats_mode=diff[p];[b][p]paletteuse=dither=bayer:bayer_scale=4`;
  const a = ['-y'];
  if (start > 0) a.push('-ss', String(start));
  if (dur > 0) a.push('-t', String(dur));
  a.push('-i', file, '-filter_complex', vf, outFile);
  return a;
}

async function gifEstimate(file, width, fps, start, dur) {
  const total = dur > 0 ? dur : Math.max((await ffprobeDuration(file)) - start, 0.1);
  const sample = Math.min(2.5, total);
  const tmp = path.join(os.tmpdir(), 'vdl-est-' + Date.now() + '.gif');
  await new Promise((resolve, reject) => {
    const p = spawn(FFMPEG, gifArgs(file, tmp, width, fps, start, sample));
    p.on('close', c => c === 0 ? resolve() : reject(new Error('estimate encode failed')));
  });
  const size = fs.statSync(tmp).size * (total / sample);
  try { fs.unlinkSync(tmp); } catch {}
  return { bytes: Math.round(size), seconds: total };
}

async function startGif(file, width, fps, start, dur) {
  width = Math.round(Math.min(4096, Math.max(16, Number(width) || 480)));   // 也進輸出檔名
  const base = path.basename(file).replace(/\.[^.]+$/, '');
  const outFile = path.join(GIFOUT, `${base}_${width}px.gif`);
  const job = newJob('GIF ' + width + 'px', path.basename(file));
  const total = dur > 0 ? dur : Math.max((await ffprobeDuration(file)) - start, 0.1);
  const p = spawn(FFMPEG, gifArgs(file, outFile, width, fps, start, dur));
  p.stderr.on('data', d => {
    const s = d.toString();
    const m = s.match(/time=(\d+):(\d+):([\d.]+)/);
    if (m) {
      const t = (+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3]);
      job.progress = Math.min(99, t / total * 100);
    }
    for (const line of s.split('\n')) if (line.includes('Error') || line.includes('Invalid')) jobLog(job, line);
  });
  p.on('close', code => {
    if (code === 0) {
      job.status = 'done'; job.progress = 100; job.file = outFile;
      try { job.size = fs.statSync(outFile).size; } catch {}
      addHist({ type: 'GIF', title: path.basename(outFile), file: outFile, status: 'ok' });
    } else {
      job.status = 'error';
      job.error = job.log.slice(-6).join('\n') || 'ffmpeg exit ' + code;
      addHist({ type: 'GIF', title: path.basename(file), status: 'error', error: job.error });
    }
  });
  return job;
}

// ---------- HTTP ----------
function send(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}
function body(req) {
  return new Promise(resolve => {
    let b = '';
    req.on('data', c => { b += c; if (b.length > 1e6) req.destroy(); });
    req.on('end', () => { try { resolve(JSON.parse(b || '{}')); } catch { resolve({}); } });
  });
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://x');
  // 只收本機自己的介面頁（同源）或沒有 Origin 的本機程式；別的網頁一律擋（含不觸發 preflight 的 text/plain POST）
  const origin = req.headers.origin;
  if (!OK_HOSTS.includes(req.headers.host || '') || (origin && !OK_ORIGINS.includes(origin))) {
    return send(res, 403, { error: '只收本機介面送來的請求' });
  }
  try {
    if (u.pathname === '/') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(fs.readFileSync(path.join(__dirname, 'index.html')));
    }
    if (u.pathname === '/ping') return send(res, 200, { ok: true });

    if (u.pathname === '/probe' && req.method === 'POST') {
      const { urls } = await body(req);
      const results = [];
      for (const url of (Array.isArray(urls) ? urls : []).slice(0, 20)) {
        if (!isWebUrl(url)) { results.push({ url, error: '只收 http／https 網址' }); continue; }
        try {
          results.push(isTvcf(url) ? await probeTvcf(url) : await probeGeneric(url));
        } catch (e) {
          let hint = '';
          if (url.includes('xinpianchang') && /403|406/.test(String(e.message)))
            hint = '新片场的「影片頁網址」目前有安全驗證，貼頁面網址進不去。改這樣做：' +
                   '① 用 Chrome 開影片頁　② 用「猫抓」擴充複製影片檔連結（xpccdn 開頭的 .mp4）　' +
                   '③ 把那條連結貼回來這裡。連結幾小時內有效，複製後盡快用。';
          results.push({ url, error: String(e.message), hint });
        }
      }
      return send(res, 200, { results });
    }
    if (u.pathname === '/download' && req.method === 'POST') {
      const { item, height, audioOnly } = await body(req);
      const job = startDownload(item, height, audioOnly);
      return send(res, 200, { id: job.id });
    }
    if (u.pathname === '/jobs') return send(res, 200, { jobs: Object.values(jobs).slice(-30) });
    if (u.pathname === '/history') return send(res, 200, { history: loadHist().slice(0, 60) });
    if (u.pathname === '/files') {
      const list = fs.readdirSync(OUT)
        .filter(f => /\.(mp4|mov|webm|mkv|m4v)$/i.test(f))
        .map(f => ({ name: f, full: path.join(OUT, f), mtime: fs.statSync(path.join(OUT, f)).mtimeMs }))
        .sort((a, b) => b.mtime - a.mtime).slice(0, 60);
      return send(res, 200, { files: list });
    }
    if (u.pathname === '/gif-estimate' && req.method === 'POST') {
      const { file: f0, width, fps, start, duration } = await body(req);
      const file = inOut(f0);
      if (!file) return send(res, 400, { error: '只能處理下載資料夾裡的檔案' });
      const r = await gifEstimate(file, width || 480, fps || 12, start || 0, duration || 0);
      return send(res, 200, r);
    }
    if (u.pathname === '/gif' && req.method === 'POST') {
      const { file: f0, width, fps, start, duration } = await body(req);
      const file = inOut(f0);
      if (!file) return send(res, 400, { error: '只能處理下載資料夾裡的檔案' });
      const job = await startGif(file, width || 480, fps || 12, start || 0, duration || 0);
      return send(res, 200, { id: job.id });
    }
    if (u.pathname === '/reveal' && req.method === 'POST') {
      const file = inOut((await body(req)).file);
      if (file) spawn('open', ['-R', file]);
      return send(res, 200, { ok: true });
    }
    send(res, 404, { error: 'not found' });
  } catch (e) {
    send(res, 500, { error: String(e.message || e) });
  }
});

server.listen(PORT, '127.0.0.1', () => console.log('vdl-app on http://127.0.0.1:' + PORT));
