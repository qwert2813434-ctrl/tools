#!/bin/zsh
# 影片資料工具啟動器 — 由 影片下載.app 呼叫
PORT=47831

# 找 node：系統 PATH → 安裝包版 → nvm
if ! command -v node >/dev/null 2>&1; then
  if [[ -x "$HOME/bin/vdl-node/bin/node" ]]; then
    export PATH="$HOME/bin/vdl-node/bin:$PATH"
  else
    nvm_bins=($HOME/.nvm/versions/node/*/bin(Nn))
    (( ${#nvm_bins[@]} > 0 )) && export PATH="${nvm_bins[-1]}:$PATH"
  fi
fi

if ! curl -s --max-time 1 "http://127.0.0.1:$PORT/ping" >/dev/null 2>&1; then
  nohup node "$HOME/bin/vdl-app/server.js" >> "$HOME/Library/Logs/vdl-app.log" 2>&1 &
  for i in {1..40}; do
    curl -s --max-time 1 "http://127.0.0.1:$PORT/ping" >/dev/null 2>&1 && break
    sleep 0.25
  done
fi

open "http://127.0.0.1:$PORT/"
