#!/bin/zsh
# 影片資料工具啟動器 — 由 影片下載.app 呼叫
PORT=47831
LOG="$HOME/Library/Logs/vdl-app.log"

# App 啟動時 PATH 只有系統目錄，先把常見 node 位置補進來
# （安裝包版 → Homebrew → /usr/local → nvm）
export PATH="$HOME/bin/vdl-node/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
if ! command -v node >/dev/null 2>&1; then
  nvm_bins=($HOME/.nvm/versions/node/*/bin(Nn))
  (( ${#nvm_bins[@]} > 0 )) && export PATH="${nvm_bins[-1]}:$PATH"
fi

if ! command -v node >/dev/null 2>&1; then
  osascript -e 'display alert "影片下載工具無法啟動" message "找不到 Node 執行環境。請重新下載最新版安裝包，再跑一次「安裝.command」（右鍵 → 打開）。" as critical'
  exit 1
fi

if ! curl -s --max-time 1 "http://127.0.0.1:$PORT/ping" >/dev/null 2>&1; then
  echo "----- $(date '+%Y-%m-%d %H:%M:%S') 啟動 -----" >> "$LOG"
  nohup node "$HOME/bin/vdl-app/server.js" >> "$LOG" 2>&1 &
  for i in {1..40}; do
    curl -s --max-time 1 "http://127.0.0.1:$PORT/ping" >/dev/null 2>&1 && break
    sleep 0.25
  done
fi

# 伺服器活著才開網頁；死了就報錯並打開記錄檔，不要開一個「無法顯示」的頁面
if curl -s --max-time 1 "http://127.0.0.1:$PORT/ping" >/dev/null 2>&1; then
  open "http://127.0.0.1:$PORT/"
else
  osascript -e 'display alert "影片下載工具啟動失敗" message "背景伺服器沒有啟動成功。即將打開錯誤記錄檔，請把最後幾行傳給提供你這個工具的人。" as critical'
  open -a TextEdit "$LOG" 2>/dev/null || open "$LOG"
  exit 1
fi
