on run
	do shell script "/bin/zsh $HOME/bin/vdl-app/start.sh"
end run
