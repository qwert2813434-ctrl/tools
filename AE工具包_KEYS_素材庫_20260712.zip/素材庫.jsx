// 素材庫 v0.5 — After Effects ScriptUI 面板
// 把選取圖層（含關鍵影格/特效/表達式）存成獨立 .aep＋PNG 縮圖，縮圖網格點擊匯入
// 素材存放：~/Downloads/VS code/14 - AE素材/動畫物件庫/
//
// 存入原理（有風險，已對使用者揭露）：
//   先儲存目前專案 → 複製合成並只留選取圖層 → 截縮圖 → reduceProject 剝掉其他
//   → 另存為素材 .aep → 重新開回原專案。過程會「存檔＋重開專案」，復原歷史會清空。

(function (thisObj) {

    var SCRIPT_NAME = "素材庫 v0.5.1";
    // 素材存放路徑：Armin 本機用工作層路徑；其他電腦自動改用「文件/AE動畫物件庫」
    var ARMIN_PATH = "/Users/arminkao/Downloads/VS code/14 - AE素材/動畫物件庫";
    var LIB_PATH = new Folder(ARMIN_PATH).parent.exists
        ? ARMIN_PATH
        : Folder.myDocuments.fsName + "/AE動畫物件庫";
    var THUMB_W = 200, THUMB_H = 112;

    var COL = {
        bg:    [0.086, 0.086, 0.098, 1],
        text:  [0.91, 0.90, 0.88, 1],
        muted: [0.52, 0.52, 0.56, 1],
        gold:  [0.83, 0.69, 0.42, 1],
        save:  [0.16, 0.68, 0.62, 1]
    };

    function libFolder() {
        var f = new Folder(LIB_PATH);
        if (!f.exists) f.create();
        return f;
    }

    function sanitize(name) {
        return name.replace(/[\/\\:*?"<>|]/g, "_").replace(/^\s+|\s+$/g, "");
    }

    // ---------- 外部素材檢查 ----------
    // 遞迴掃描圖層（含預組合）引用的外部檔案，回傳 File 陣列
    function findExternalFootage(layers, depth, out, seen) {
        if (depth > 6) return out;
        for (var i = 0; i < layers.length; i++) {
            var ly = layers[i];
            var src = null;
            try { src = ly.source; } catch (eS) {}
            if (!src) continue;
            if (src instanceof CompItem) {
                if (!seen[src.id]) {
                    seen[src.id] = true;
                    var inner = [];
                    for (var L = 1; L <= src.numLayers; L++) inner.push(src.layer(L));
                    findExternalFootage(inner, depth + 1, out, seen);
                }
            } else if (src instanceof FootageItem) {
                var ms = src.mainSource;
                if (ms instanceof FileSource && ms.file && !seen["f" + src.id]) {
                    seen["f" + src.id] = true;
                    out.push(ms.file);
                }
            }
        }
        return out;
    }

    // 把打包後專案裡的外部檔複製進 素材名_files/ 並重新連結
    function collectExternals(baseName) {
        var filesDir = new Folder(libFolder().fsName + "/" + baseName + "_files");
        var failed = [];
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it instanceof FootageItem && it.mainSource instanceof FileSource && it.mainSource.file) {
                var srcFile = it.mainSource.file;
                if (!srcFile.exists) { failed.push(decodeURI(srcFile.name) + "（原檔已遺失）"); continue; }
                if (!filesDir.exists) filesDir.create();
                var destFile = new File(filesDir.fsName + "/" + srcFile.name);
                try {
                    if (srcFile.copy(destFile.fsName)) it.replace(destFile);
                    else failed.push(decodeURI(srcFile.name));
                } catch (eC) { failed.push(decodeURI(srcFile.name)); }
            }
        }
        return failed;
    }

    // ---------- 存入 ----------

    function saveAsset(assetName) {
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) { alert("請先開啟合成。"); return false; }
        var selLayers = comp.selectedLayers;
        if (selLayers.length === 0) { alert("請先選取要保存的圖層。"); return false; }
        if (!app.project.file) {
            alert("目前專案還沒存過檔。請先 ⌘S 存檔一次再存素材。");
            return false;
        }

        // 外部素材檢查：防止日後斷鏈
        var externals = findExternalFootage(selLayers, 0, [], {});
        var copyExternals = false;
        if (externals.length > 0) {
            var names = [];
            for (var x = 0; x < Math.min(externals.length, 8); x++) names.push("・" + decodeURI(externals[x].name));
            if (externals.length > 8) names.push("…共 " + externals.length + " 個");
            if (!confirm(
                "⚠ 這個素材引用了 " + externals.length + " 個外部檔案：\n" + names.join("\n") +
                "\n\n外部檔案搬家或換電腦會讓素材斷鏈。\n要繼續存入嗎？")) return false;
            copyExternals = confirm(
                "要把這些外部檔案「複製一份」進素材資料夾一起收藏嗎？\n" +
                "（建議「是」——素材從此自給自足；「否」則只存路徑引用）");
        }

        var ok = confirm(
            "存入素材「" + assetName + "」\n\n" +
            "流程：先儲存目前專案 → 打包素材 → 自動重開專案。\n" +
            "⚠ 重開後「復原歷史（⌘Z）」會清空，目前工作內容不會遺失。\n" +
            "縮圖＝目前時間指針的畫面（請先把指針停在素材最好看的一格）。\n\n繼續？"
        );
        if (!ok) return false;

        var originalFile = app.project.file;
        var baseName = sanitize(assetName);
        var aepFile = new File(libFolder().fsName + "/" + baseName + ".aep");
        var pngFile = new File(libFolder().fsName + "/" + baseName + ".png");
        if (aepFile.exists && !confirm("已有同名素材「" + baseName + "」，要覆蓋嗎？")) return false;

        // 記下選取圖層 index 與截圖時間
        var keepIdx = {};
        for (var i = 0; i < selLayers.length; i++) keepIdx[selLayers[i].index] = true;
        var snapT = comp.time;

        try {
            app.beginSuppressDialogs();

            // 1. 先存目前專案（使用者狀態的保險）
            app.project.save();

            // 2. 複製合成，刪掉未選取的圖層（保留選取圖層間的父子/順序）
            var dup = comp.duplicate();
            dup.name = "AST_" + baseName;
            for (var L = dup.numLayers; L >= 1; L--) {
                if (!keepIdx[L]) dup.layer(L).remove();
            }

            // 3. 縮圖：小合成嵌套後截 PNG（指針畫面）
            var tmb = app.project.items.addComp("TMB_" + baseName,
                THUMB_W, THUMB_H, 1, Math.max(dup.duration, 1), dup.frameRate);
            var nest = tmb.layers.add(dup);
            var s = Math.min(THUMB_W / dup.width, THUMB_H / dup.height) * 100;
            nest.transform.scale.setValue([s, s]);
            nest.transform.position.setValue([THUMB_W / 2, THUMB_H / 2]);
            var snapClamped = Math.min(snapT, tmb.duration - tmb.frameDuration);
            tmb.saveFrameToPng(snapClamped, pngFile);
            // 驗證縮圖真的寫出來了，沒有就等一下再試一次（saveFrameToPng 偶爾沒落地）
            if (!pngFile.exists) { $.sleep(400); }
            if (!pngFile.exists) {
                tmb.saveFrameToPng(Math.max(0, tmb.duration / 2), pngFile);
                $.sleep(400);
            }
            tmb.remove();

            // 4. 剝掉其他項目 → （可選）收藏外部檔 → 另存為素材檔
            app.project.reduceProject([dup]);
            var collectFailed = [];
            if (copyExternals) collectFailed = collectExternals(baseName);
            app.project.save(aepFile);

            // 5. 開回原專案
            app.open(originalFile);
            app.endSuppressDialogs(false);
            if (collectFailed.length > 0) {
                alert("素材已存入，但這些外部檔複製失敗（素材仍引用原路徑）：\n・" + collectFailed.join("\n・"));
            }
            return true;
        } catch (e) {
            try { app.endSuppressDialogs(false); } catch (e2) {}
            alert("存入失敗：" + e.toString() +
                "\n\n你的原專案安全存在：\n" + originalFile.fsName +
                "\n若目前開著的是打包中的暫存狀態，直接重新開啟上面那個檔即可。");
            try { app.open(originalFile); } catch (e3) {}
            return false;
        }
    }

    // ---------- 補縮圖（開素材檔渲染一張再回來） ----------

    function regenThumb(baseName) {
        var aepFile = new File(libFolder().fsName + "/" + baseName + ".aep");
        var pngFile = new File(libFolder().fsName + "/" + baseName + ".png");
        if (!aepFile.exists) { alert("找不到素材檔：" + baseName + ".aep"); return false; }
        if (!app.project.file) {
            alert("目前專案還沒存過檔。請先 ⌘S 存檔一次再補縮圖。");
            return false;
        }
        if (!confirm("補縮圖「" + baseName + "」\n\n流程：先儲存目前專案 → 開素材檔渲染縮圖 → 自動開回來。\n⚠ 復原歷史（⌘Z）會清空。繼續？")) return false;

        var originalFile = app.project.file;
        try {
            app.beginSuppressDialogs();
            app.project.save();
            app.open(aepFile);

            var ast = null;
            for (var i = 1; i <= app.project.numItems; i++) {
                var it = app.project.item(i);
                if (it instanceof CompItem) {
                    ast = it;
                    if (it.name.indexOf("AST_") === 0) break;
                }
            }
            if (!ast) throw new Error("素材檔裡找不到合成");

            var tmb = app.project.items.addComp("TMB", THUMB_W, THUMB_H, 1,
                Math.max(ast.duration, 1), ast.frameRate);
            var nest = tmb.layers.add(ast);
            var s = Math.min(THUMB_W / ast.width, THUMB_H / ast.height) * 100;
            nest.transform.scale.setValue([s, s]);
            nest.transform.position.setValue([THUMB_W / 2, THUMB_H / 2]);
            tmb.saveFrameToPng(tmb.duration / 2, pngFile);
            if (!pngFile.exists) { $.sleep(400); }

            app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES);
            app.open(originalFile);
            app.endSuppressDialogs(false);
            return pngFile.exists;
        } catch (e) {
            try { app.endSuppressDialogs(false); } catch (e2) {}
            alert("補縮圖失敗：" + e.toString() + "\n原專案在：" + originalFile.fsName);
            try { app.open(originalFile); } catch (e3) {}
            return false;
        }
    }

    // ---------- 匯入 ----------

    // 專案面板裡的「素材庫」整理資料夾（沒有就建）
    function getProjLibFolder() {
        var root = app.project.rootFolder;
        for (var i = 1; i <= root.numItems; i++) {
            var it = root.item(i);
            if (it instanceof FolderItem && it.name === "素材庫") return it;
        }
        return app.project.items.addFolder("素材庫");
    }

    function importAsset(baseName, placeInComp) {
        var aepFile = new File(libFolder().fsName + "/" + baseName + ".aep");
        if (!aepFile.exists) { alert("找不到素材檔：" + baseName + ".aep"); return; }
        var targetComp = (app.project.activeItem instanceof CompItem) ? app.project.activeItem : null;
        app.beginUndoGroup("匯入素材 " + baseName);
        try {
            // 去重：同素材已在專案裡就直接重用，不重複匯入
            var theComp = null;
            for (var d = 1; d <= app.project.numItems; d++) {
                var ex = app.project.item(d);
                if (ex instanceof CompItem && ex.name === "AST_" + baseName) { theComp = ex; break; }
            }
            if (!theComp) {
                var imported = app.project.importFile(new ImportOptions(aepFile));
                if (imported instanceof FolderItem) {
                    imported.parentFolder = getProjLibFolder(); // 收進「素材庫」資料夾
                    for (var i = 1; i <= imported.numItems; i++) {
                        var it = imported.item(i);
                        if (it instanceof CompItem) {
                            theComp = it;
                            if (it.name.indexOf("AST_") === 0) break;
                        }
                    }
                }
            }
            if (placeInComp && targetComp && theComp) {
                var ly = targetComp.layers.add(theComp);
                ly.startTime = targetComp.time;
            }
        } catch (e) {
            alert("匯入失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
    }

    // ---------- UI ----------

    function paintText(st, colorArr) {
        try {
            st.graphics.foregroundColor =
                st.graphics.newPen(st.graphics.PenType.SOLID_COLOR, colorArr, 1);
        } catch (e) {}
    }

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", SCRIPT_NAME, undefined, { resizeable: true });
        try {
            win.graphics.backgroundColor =
                win.graphics.newBrush(win.graphics.BrushType.SOLID_COLOR, COL.bg);
        } catch (eBG) {}

        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 8;
        win.margins = 12;

        var head = win.add("group");
        var title = head.add("statictext", undefined, "素 材 庫");
        paintText(title, COL.gold);
        var ver = head.add("statictext", undefined, "v0.5");
        paintText(ver, COL.muted);

        // 存入列
        var rowSave = win.add("group");
        rowSave.orientation = "row";
        rowSave.alignChildren = ["left", "center"];
        var lblN = rowSave.add("statictext", undefined, "名稱");
        paintText(lblN, COL.text);
        var etName = rowSave.add("edittext", undefined, "");
        etName.characters = 14;
        var btnSave = rowSave.add("button", undefined, "存入選取圖層");
        btnSave.helpTip = "把時間軸選取的圖層（含動畫/特效/表達式）打包成素材\n縮圖＝目前時間指針畫面\n⚠ 會先存檔並重開專案（復原歷史清空）";
        btnSave.onClick = function () {
            var n = sanitize(etName.text);
            if (!n) { alert("請先輸入素材名稱。"); return; }
            if (saveAsset(n)) {
                etName.text = "";
                refreshGrid();
                alert("已存入素材庫：" + n);
            }
        };

        var rowTools = win.add("group");
        var btnRefresh = rowTools.add("button", undefined, "重新整理");
        btnRefresh.onClick = function () { refreshGrid(); };
        var btnOpenLib = rowTools.add("button", undefined, "開啟素材資料夾");
        btnOpenLib.onClick = function () { libFolder().execute(); };

        var hintTop = win.add("statictext", undefined,
            "點縮圖＝匯入並放到目前合成的指針處｜⌥點＝只匯入專案面板", { multiline: true });
        paintText(hintTop, COL.muted);

        // 縮圖網格（固定高度視窗＋捲軸，素材多了往下捲）
        var VIEW_W = 450, VIEW_H = 400;
        var viewport = win.add("group");
        viewport.orientation = "row";
        viewport.alignChildren = ["left", "top"];
        viewport.spacing = 2;

        var view = viewport.add("panel");
        view.preferredSize = [VIEW_W, VIEW_H];
        view.minimumSize = [VIEW_W, VIEW_H];
        view.maximumSize = [VIEW_W, VIEW_H];
        view.margins = 8;
        view.alignChildren = ["left", "top"];

        var content = view.add("group");
        content.orientation = "column";
        content.alignChildren = ["left", "top"];
        content.spacing = 10;

        var sb = viewport.add("scrollbar");
        sb.preferredSize = [16, VIEW_H];
        var contentBaseY = 0;
        sb.onChanging = function () {
            content.location = [content.location[0], contentBaseY - sb.value];
        };

        // 依內容與可視高度重算捲軸範圍
        function recalcScroll() {
            contentBaseY = content.location[1];
            var overflow = Math.max(0, content.size[1] - (view.size[1] - 16));
            sb.minvalue = 0;
            sb.maxvalue = overflow;
            if (sb.value > overflow) sb.value = overflow;
            sb.stepdelta = 130;
            sb.jumpdelta = Math.max(100, view.size[1] - 40);
            sb.enabled = overflow > 0;
        }

        // 預覽區貼合面板目前大小（停靠多高就顯示多高）
        function fitViewport() {
            try {
                var availH = Math.max(160, win.size[1] - viewport.location[1] - 14);
                var availW = Math.max(260, win.size[0] - 24 - 20);
                view.minimumSize = [availW, availH];
                view.maximumSize = [availW, availH];
                view.preferredSize = [availW, availH];
                sb.minimumSize = [16, availH];
                sb.maximumSize = [16, availH];
                sb.preferredSize = [16, availH];
                win.layout.layout(true);
                recalcScroll();
            } catch (eF) {}
        }

        function refreshGrid() {
            while (content.children.length > 0) content.remove(content.children[0]);
            var aeps = libFolder().getFiles("*.aep"); // 以素材本體為準，沒縮圖也要列出
            if (aeps.length === 0) {
                var empty = content.add("statictext", undefined, "（還沒有素材——選好圖層、取個名字、按「存入選取圖層」）");
                paintText(empty, COL.muted);
            } else {
                aeps.sort(function (a, b) { return a.name > b.name ? 1 : -1; });
                var row = null;
                for (var i = 0; i < aeps.length; i++) {
                    if (i % 2 === 0) {
                        row = content.add("group");
                        row.orientation = "row";
                        row.spacing = 10;
                        row.alignChildren = ["left", "top"];
                    }
                    var base = decodeURI(aeps[i].name).replace(/\.aep$/i, "");
                    var png = new File(libFolder().fsName + "/" + base + ".png");
                    var cell = row.add("group");
                    cell.orientation = "column";
                    cell.spacing = 2;
                    cell.alignChildren = ["center", "top"];
                    var btn = null;
                    if (png.exists) {
                        try {
                            btn = cell.add("iconbutton", undefined, png, { style: "toolbutton" });
                        } catch (eImg) { btn = null; }
                    }
                    if (!btn) {
                        btn = cell.add("button", undefined, "（無縮圖）" + base);
                        btn.preferredSize = [THUMB_W, THUMB_H];
                    }
                    btn.helpTip = base + "\n點＝匯入並放到目前合成指針處\n⌥ 點＝只匯入專案面板";
                    var lbl = cell.add("statictext", undefined, base);
                    paintText(lbl, COL.text);
                    (function (b) {
                        btn.onClick = function () {
                            var alt = false;
                            try { alt = ScriptUI.environment.keyboardState.altKey; } catch (eK) {}
                            importAsset(b, !alt);
                        };
                    })(base);
                    if (!png.exists) {
                        var btnRegen = cell.add("button", undefined, "補縮圖");
                        btnRegen.helpTip = "開素材檔渲染一張縮圖再自動回來（會先存檔目前專案）";
                        (function (b2) {
                            btnRegen.onClick = function () {
                                if (regenThumb(b2)) refreshGrid();
                            };
                        })(base);
                    }
                }
            }
            win.layout.layout(true);
            win.layout.resize();
            sb.value = 0;
            recalcScroll();
        }

        refreshGrid();
        fitViewport();

        win.onResizing = win.onResize = function () {
            this.layout.resize();
            fitViewport();
        };
        if (win instanceof Window) {
            win.center();
            win.show();
        }
        return win;
    }

    buildUI(thisObj);

})(this);
