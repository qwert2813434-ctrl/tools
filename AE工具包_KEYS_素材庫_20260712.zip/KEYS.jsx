// KEYS 關鍵影格助手 v0.3 — After Effects ScriptUI 面板（Motion 風格自繪 UI）
// KEYboard 風格的關鍵影格工作流工具（原創實作）
// 操作邏輯：彩色工具鈕＋修飾鍵變化（滑鼠停在按鈕上會顯示說明）
//   EASE 鈕：點=緩入緩出｜⌥點=只緩入｜⌘點=只緩出｜⇧點=線性
//   SHIFT 鈕：點=移1格｜⇧點=移10格；面板聚焦時 ←/→（⇧=10格）
//   ANCHOR 九宮格：錨點移到指定位置，畫面位置不變（自動補償位置）
// 字母快捷鍵不使用，保留給 AE 屬性鍵（E/S/P/R/T/U…）

(function (thisObj) {

    var SCRIPT_NAME = "KEYS v0.7";

    // ---------- 配色 ----------
    var COL = {
        bg:     [0.086, 0.086, 0.098, 1],
        text:   [0.91, 0.90, 0.88, 1],
        muted:  [0.52, 0.52, 0.56, 1],
        gold:   [0.83, 0.69, 0.42, 1],
        ease:   [0.16, 0.68, 0.62, 1],   // 湖水綠
        clone:  [0.93, 0.60, 0.29, 1],   // 橘
        mirror: [0.58, 0.43, 0.82, 1],   // 紫
        bounce: [0.85, 0.38, 0.42, 1],   // 珊瑚紅
        value:  [0.48, 0.70, 0.42, 1],   // 綠
        expr:   [0.42, 0.60, 0.78, 1],   // 天藍
        trans:  [0.78, 0.42, 0.62, 1],   // 洋紅
        shift:  [0.33, 0.47, 0.66, 1],   // 藍灰
        dark:   [0.06, 0.06, 0.07, 1]
    };
    function lighten(c, amt) {
        return [Math.min(c[0] + amt, 1), Math.min(c[1] + amt, 1), Math.min(c[2] + amt, 1), 1];
    }

    // ---------- 選取檢查 ----------

    function getComp() {
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) {
            alert("請先開啟一個合成。");
            return null;
        }
        return comp;
    }

    function getPropsWithSelectedKeys() {
        var comp = getComp();
        if (!comp) return null;
        var props = comp.selectedProperties;
        var out = [];
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            if (p instanceof Property && p.numKeys > 0 && p.selectedKeys.length > 0) {
                out.push(p);
            }
        }
        if (out.length === 0) {
            alert("請先在時間軸選取關鍵影格。");
            return null;
        }
        return out;
    }

    // ---------- 關鍵影格讀寫 ----------

    function captureKeys(prop, indices) {
        var keys = [];
        for (var i = 0; i < indices.length; i++) {
            var k = indices[i];
            var d = {
                time: prop.keyTime(k),
                value: prop.keyValue(k),
                inInterp: prop.keyInInterpolationType(k),
                outInterp: prop.keyOutInterpolationType(k),
                inEase: prop.keyInTemporalEase(k),
                outEase: prop.keyOutTemporalEase(k),
                tCont: prop.keyTemporalContinuous(k),
                tAuto: prop.keyTemporalAutoBezier(k)
            };
            if (prop.isSpatial) {
                d.inTan = prop.keyInSpatialTangent(k);
                d.outTan = prop.keyOutSpatialTangent(k);
                d.sCont = prop.keySpatialContinuous(k);
                d.sAuto = prop.keySpatialAutoBezier(k);
                d.roving = prop.keyRoving(k);
            }
            keys.push(d);
        }
        return keys;
    }

    function writeKey(prop, d, time) {
        var idx = prop.addKey(time);
        prop.setValueAtKey(idx, d.value);
        try { prop.setTemporalEaseAtKey(idx, d.inEase, d.outEase); } catch (e1) {}
        try { prop.setInterpolationTypeAtKey(idx, d.inInterp, d.outInterp); } catch (e2) {}
        try {
            prop.setTemporalContinuousAtKey(idx, d.tCont);
            prop.setTemporalAutoBezierAtKey(idx, d.tAuto);
        } catch (e3) {}
        if (prop.isSpatial && d.inTan) {
            try {
                prop.setSpatialTangentsAtKey(idx, d.inTan, d.outTan);
                prop.setSpatialContinuousAtKey(idx, d.sCont);
                prop.setSpatialAutoBezierAtKey(idx, d.sAuto);
                prop.setRovingAtKey(idx, d.roving);
            } catch (e4) {}
        }
        return idx;
    }

    function removeKeysDescending(prop, indices) {
        var sorted = indices.concat().sort(function (a, b) { return b - a; });
        for (var i = 0; i < sorted.length; i++) prop.removeKey(sorted[i]);
    }

    function negateEase(easeArr) {
        var out = [];
        for (var i = 0; i < easeArr.length; i++) {
            out.push(new KeyframeEase(-easeArr[i].speed, easeArr[i].influence));
        }
        return out;
    }

    // ---------- 四大功能 ----------

    function applyEase(mode, infIn, infOut) {
        var props = getPropsWithSelectedKeys();
        if (!props) return;
        app.beginUndoGroup("KEYS Ease");
        try {
            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                var sel = prop.selectedKeys.concat();
                for (var j = 0; j < sel.length; j++) {
                    var k = sel[j];
                    if (mode === "linear") {
                        prop.setInterpolationTypeAtKey(k,
                            KeyframeInterpolationType.LINEAR,
                            KeyframeInterpolationType.LINEAR);
                        continue;
                    }
                    var curIn = prop.keyInTemporalEase(k);
                    var curOut = prop.keyOutTemporalEase(k);
                    var newIn = [], newOut = [], n;
                    for (n = 0; n < curIn.length; n++) newIn.push(new KeyframeEase(0, infIn));
                    for (n = 0; n < curOut.length; n++) newOut.push(new KeyframeEase(0, infOut));
                    if (mode === "both") {
                        prop.setTemporalEaseAtKey(k, newIn, newOut);
                        prop.setInterpolationTypeAtKey(k,
                            KeyframeInterpolationType.BEZIER,
                            KeyframeInterpolationType.BEZIER);
                    } else if (mode === "in") {
                        prop.setTemporalEaseAtKey(k, newIn, curOut);
                        prop.setInterpolationTypeAtKey(k,
                            KeyframeInterpolationType.BEZIER,
                            prop.keyOutInterpolationType(k));
                    } else {
                        prop.setTemporalEaseAtKey(k, curIn, newOut);
                        prop.setInterpolationTypeAtKey(k,
                            prop.keyInInterpolationType(k),
                            KeyframeInterpolationType.BEZIER);
                    }
                }
            }
        } catch (e) {
            alert("Ease 套用失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
    }

    // mode="append"  ：接續複製（貼在結尾後一格，連點=重複循環）
    // mode="mirror"  ：鏡像接續（複製段反轉接在結尾，形成 ping-pong 來回）
    // mode="playhead"：貼到時間指針（第一顆對齊指針，保留相對時距）
    function cloneKeys(mode) {
        var props = getPropsWithSelectedKeys();
        if (!props) return;
        var comp = app.project.activeItem;
        app.beginUndoGroup("KEYS Clone " + mode);
        try {
            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                var sel = prop.selectedKeys.concat().sort(function (a, b) { return a - b; });
                var data = captureKeys(prop, sel);
                var j, d;
                if (mode === "mirror") {
                    if (data.length < 2) continue;
                    var lastT = data[data.length - 1].time;
                    // 轉折點（原最後一顆）的出向緩動改為入向的鏡像，讓折返順暢
                    try {
                        var bIn = data[data.length - 1].inEase;
                        prop.setTemporalEaseAtKey(sel[sel.length - 1], bIn, negateEase(bIn));
                    } catch (eB) {}
                    // 其餘各顆反轉時間接在後面（最後一顆本身就是轉折點，跳過）
                    for (j = data.length - 2; j >= 0; j--) {
                        d = data[j];
                        var m = {
                            time: lastT + (lastT - d.time),
                            value: d.value,
                            inInterp: d.outInterp,
                            outInterp: d.inInterp,
                            inEase: negateEase(d.outEase),
                            outEase: negateEase(d.inEase),
                            tCont: d.tCont,
                            tAuto: d.tAuto
                        };
                        if (prop.isSpatial && d.inTan) {
                            m.inTan = d.outTan;
                            m.outTan = d.inTan;
                            m.sCont = d.sCont;
                            m.sAuto = d.sAuto;
                            m.roving = d.roving;
                        }
                        try { writeKey(prop, m, m.time); } catch (eK1) {}
                    }
                } else {
                    var offset;
                    if (mode === "playhead") {
                        offset = comp.time - data[0].time;
                    } else {
                        var span = data[data.length - 1].time - data[0].time;
                        offset = span + comp.frameDuration;
                    }
                    for (j = 0; j < data.length; j++) {
                        try { writeKey(prop, data[j], data[j].time + offset); }
                        catch (eK2) {}
                    }
                }
            }
        } catch (e) {
            alert("Clone 失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
    }

    function mirrorKeys() {
        var props = getPropsWithSelectedKeys();
        if (!props) return;
        app.beginUndoGroup("KEYS Mirror");
        try {
            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                var sel = prop.selectedKeys.concat().sort(function (a, b) { return a - b; });
                if (sel.length < 2) continue;
                var data = captureKeys(prop, sel);
                var pivotSum = data[0].time + data[data.length - 1].time;
                removeKeysDescending(prop, sel);
                for (var j = 0; j < data.length; j++) {
                    var d = data[j];
                    var m = {
                        time: pivotSum - d.time,
                        value: d.value,
                        inInterp: d.outInterp,
                        outInterp: d.inInterp,
                        inEase: negateEase(d.outEase),
                        outEase: negateEase(d.inEase),
                        tCont: d.tCont,
                        tAuto: d.tAuto
                    };
                    if (prop.isSpatial && d.inTan) {
                        m.inTan = d.outTan;
                        m.outTan = d.inTan;
                        m.sCont = d.sCont;
                        m.sAuto = d.sAuto;
                        m.roving = d.roving;
                    }
                    try { writeKey(prop, m, m.time); } catch (eK) {}
                }
            }
        } catch (e) {
            alert("Mirror 失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
    }

    function shiftKeys(frames) {
        var props = getPropsWithSelectedKeys();
        if (!props) return;
        var comp = app.project.activeItem;
        var delta = frames * comp.frameDuration;
        app.beginUndoGroup("KEYS Shift");
        try {
            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                var sel = prop.selectedKeys.concat().sort(function (a, b) { return a - b; });
                var data = captureKeys(prop, sel);
                removeKeysDescending(prop, sel);
                var newIdx = [];
                for (var j = 0; j < data.length; j++) {
                    try { newIdx.push(writeKey(prop, data[j], data[j].time + delta)); }
                    catch (eK) {}
                }
                for (var s = 0; s < newIdx.length; s++) {
                    try { prop.setSelectedAtKey(newIdx[s], true); } catch (eS) {}
                }
            }
        } catch (e) {
            alert("Shift 失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
    }

    // ---------- Bounce 彈性烘焙 ----------
    // 從最後一顆選取關鍵影格的抵達速度，烘焙出衰減震盪的真實關鍵影格
    // （彈性公式思路學自開源 spring easing，改為烘焙非表達式）

    function valAdd(base, off) {
        if (base instanceof Array) {
            var out = [];
            for (var i = 0; i < base.length; i++) out.push(base[i] + off[i]);
            return out;
        }
        return base + off;
    }

    function bounceKeys(preset) {
        var props = getPropsWithSelectedKeys();
        if (!props) return;
        var comp = app.project.activeItem;
        var dt = comp.frameDuration;
        var skipped = 0;
        app.beginUndoGroup("KEYS Bounce");
        try {
            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                var sel = prop.selectedKeys.concat().sort(function (a, b) { return a - b; });
                var L = sel[sel.length - 1];
                if (L < 2) { skipped++; continue; } // 前面沒動作，算不出抵達速度
                var tL = prop.keyTime(L);
                var vEnd = prop.keyValue(L);
                var isArr = vEnd instanceof Array;
                if (!isArr && typeof vEnd !== "number") { skipped++; continue; }

                // 抵達速度（取曲線在結尾前一格的斜率）
                var vPrev = prop.valueAtTime(tL - dt, false);
                var vel, c, mag = 0;
                if (isArr) {
                    vel = [];
                    for (c = 0; c < vEnd.length; c++) {
                        vel.push((vEnd[c] - vPrev[c]) / dt);
                        mag += Math.abs(vel[c]);
                    }
                } else {
                    vel = (vEnd - vPrev) / dt;
                    mag = Math.abs(vel);
                }
                if (mag < 0.0001) { skipped++; continue; } // 結尾已緩停，彈不起來

                // 衰減震盪的波峰烘焙成關鍵影格
                var lastPeakT = tL;
                for (var k = 1; k <= 8; k++) {
                    var tk = tL + (2 * k - 1) / (4 * preset.freq);
                    var env = Math.exp(-preset.decay * (tk - tL));
                    if (env < 0.02) break;
                    var s = (k % 2 === 1) ? 1 : -1;
                    var off;
                    if (isArr) {
                        off = [];
                        for (c = 0; c < vEnd.length; c++) off.push(vel[c] * preset.amp * s * env);
                    } else {
                        off = vel * preset.amp * s * env;
                    }
                    try {
                        var idx = prop.addKey(tk);
                        prop.setValueAtKey(idx, valAdd(vEnd, off));
                        prop.setTemporalContinuousAtKey(idx, true);
                        prop.setTemporalAutoBezierAtKey(idx, true);
                        lastPeakT = tk;
                    } catch (eK) {}
                }
                // 收尾：回到原值並緩停
                try {
                    var endIdx = prop.addKey(lastPeakT + 1 / (4 * preset.freq));
                    prop.setValueAtKey(endIdx, vEnd);
                    var nDim = prop.keyInTemporalEase(endIdx).length;
                    var easeArr = [];
                    for (c = 0; c < nDim; c++) easeArr.push(new KeyframeEase(0, 60));
                    prop.setTemporalEaseAtKey(endIdx, easeArr, easeArr);
                } catch (eE) {}
            }
        } catch (e) {
            alert("Bounce 失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
        if (skipped > 0) {
            alert(skipped + " 個屬性跳過：需要至少兩顆關鍵影格、且結尾要帶著速度進來（線性或未完全緩停）才彈得起來。");
        }
    }

    // ---------- Value 批量改值 ----------
    // mode="add"：全部 +n（負數=減）｜"mul"：全部 ×n｜"rand"：每顆隨機 ±n
    // （學自 kyletmartinez Add_Value/Multiply_Selected_Keyframes，隨機為我們擴充）

    function adjustKeyValues(mode, n) {
        var props = getPropsWithSelectedKeys();
        if (!props) return;
        var skipped = 0;
        app.beginUndoGroup("KEYS Value " + mode);
        try {
            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                var sel = prop.selectedKeys.concat();
                for (var j = 0; j < sel.length; j++) {
                    var k = sel[j];
                    var v = prop.keyValue(k);
                    var nv;
                    if (v instanceof Array) {
                        nv = [];
                        for (var c = 0; c < v.length; c++) {
                            if (mode === "add") nv.push(v[c] + n);
                            else if (mode === "mul") nv.push(v[c] * n);
                            else nv.push(v[c] + (Math.random() * 2 - 1) * n);
                        }
                    } else if (typeof v === "number") {
                        if (mode === "add") nv = v + n;
                        else if (mode === "mul") nv = v * n;
                        else nv = v + (Math.random() * 2 - 1) * n;
                    } else {
                        skipped++;
                        break; // 非數值屬性（如路徑）整個跳過
                    }
                    try { prop.setValueAtKey(k, nv); } catch (eV) {}
                }
            }
        } catch (e) {
            alert("Value 失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
        if (skipped > 0) alert(skipped + " 個屬性非數值（如路徑/文字），已跳過。");
    }

    // ---------- 快速表達式 ----------

    function getExprProps() {
        var comp = getComp();
        if (!comp) return null;
        var props = comp.selectedProperties;
        var out = [];
        for (var i = 0; i < props.length; i++) {
            if (props[i] instanceof Property && props[i].canSetExpression) {
                out.push(props[i]);
            }
        }
        if (out.length === 0) {
            alert("請先在時間軸選取屬性（例如位置、縮放、不透明度）。");
            return null;
        }
        return out;
    }

    function setExpr(exprStr, undoName) {
        var props = getExprProps();
        if (!props) return;
        app.beginUndoGroup(undoName);
        try {
            for (var i = 0; i < props.length; i++) {
                props[i].expression = exprStr;
            }
        } catch (e) {
            alert("表達式套用失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
    }

    // ---------- 轉場烘焙（選圖層，從時間指針開始） ----------

    function getSelLayers() {
        var comp = getComp();
        if (!comp) return null;
        var out = [];
        for (var i = 0; i < comp.selectedLayers.length; i++) {
            var ly = comp.selectedLayers[i];
            if (ly instanceof AVLayer || ly instanceof ShapeLayer || ly instanceof TextLayer) {
                out.push(ly);
            }
        }
        if (out.length === 0) {
            alert("請先選取圖層。");
            return null;
        }
        return out;
    }

    function easeKeyAt(prop, t, inf) {
        try {
            var k = prop.nearestKeyIndex(t);
            var n = prop.keyInTemporalEase(k).length;
            var arr = [];
            for (var c = 0; c < n; c++) arr.push(new KeyframeEase(0, inf));
            prop.setTemporalEaseAtKey(k, arr, arr);
        } catch (e) {}
    }

    function holdKeyAt(prop, t) {
        try {
            var k = prop.nearestKeyIndex(t);
            prop.setInterpolationTypeAtKey(k,
                KeyframeInterpolationType.HOLD, KeyframeInterpolationType.HOLD);
        } catch (e) {}
    }

    // 閃：瞬閃亮起（dirIn=true）／瞬閃消失（false）。HOLD 關鍵影格做硬切爆閃
    function transFlash(dirIn, frames) {
        var layers = getSelLayers();
        if (!layers) return;
        var comp = app.project.activeItem;
        var D = frames * comp.frameDuration;
        var t0 = comp.time;
        var pattern = [0, 0.1, 0.2, 0.32, 0.45, 0.6, 0.72, 1]; // 不等距，比較有機
        app.beginUndoGroup("KEYS 閃" + (dirIn ? "入" : "出"));
        try {
            for (var i = 0; i < layers.length; i++) {
                var op = layers[i].transform.opacity;
                for (var p = 0; p < pattern.length; p++) {
                    var on = (p % 2 === 1); // 從暗開始交替，索引奇數=亮
                    if (p === pattern.length - 1) on = true; // 結尾亮
                    var v = dirIn ? (on ? 100 : 0) : (on ? 0 : 100); // 閃出=反轉
                    var t = t0 + pattern[p] * D;
                    op.setValueAtTime(t, v);
                    holdKeyAt(op, t);
                }
            }
        } catch (e) {
            alert("閃轉場失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
    }

    // 淡：淡入／淡出
    function transFade(dirIn, frames) {
        var layers = getSelLayers();
        if (!layers) return;
        var comp = app.project.activeItem;
        var D = frames * comp.frameDuration;
        var t0 = comp.time;
        app.beginUndoGroup("KEYS 淡" + (dirIn ? "入" : "出"));
        try {
            for (var i = 0; i < layers.length; i++) {
                var op = layers[i].transform.opacity;
                op.setValueAtTime(t0, dirIn ? 0 : 100);
                op.setValueAtTime(t0 + D, dirIn ? 100 : 0);
                easeKeyAt(op, t0, 60);
                easeKeyAt(op, t0 + D, 60);
            }
        } catch (e) {
            alert("淡轉場失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
    }

    function scaleArr(v, f) {
        var out = [];
        for (var c = 0; c < v.length; c++) out.push(v[c] * f);
        return out;
    }

    // 彈：縮放彈入（0→108%→100）／彈出（100→108%→0）
    function transPop(dirIn, frames) {
        var layers = getSelLayers();
        if (!layers) return;
        var comp = app.project.activeItem;
        var D = frames * comp.frameDuration;
        var t0 = comp.time;
        app.beginUndoGroup("KEYS 彈" + (dirIn ? "入" : "出"));
        try {
            for (var i = 0; i < layers.length; i++) {
                var sc = layers[i].transform.scale;
                var base = sc.valueAtTime(t0, false);
                if (dirIn) {
                    sc.setValueAtTime(t0, scaleArr(base, 0));
                    sc.setValueAtTime(t0 + 0.7 * D, scaleArr(base, 1.08));
                    sc.setValueAtTime(t0 + D, base);
                } else {
                    sc.setValueAtTime(t0, base);
                    sc.setValueAtTime(t0 + 0.3 * D, scaleArr(base, 1.08));
                    sc.setValueAtTime(t0 + D, scaleArr(base, 0));
                }
                easeKeyAt(sc, t0, 60);
                easeKeyAt(sc, t0 + 0.7 * D, 60);
                easeKeyAt(sc, t0 + 0.3 * D, 60);
                easeKeyAt(sc, t0 + D, 60);
            }
        } catch (e) {
            alert("彈轉場失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
    }

    // ---------- Anchor 九宮格 ----------

    function offsetProp2D(p, ox, oy) {
        if (p.numKeys > 0) {
            for (var k = 1; k <= p.numKeys; k++) {
                var v = p.keyValue(k);
                p.setValueAtKey(k, (v.length === 3)
                    ? [v[0] + ox, v[1] + oy, v[2]]
                    : [v[0] + ox, v[1] + oy]);
            }
        } else {
            var v2 = p.value;
            p.setValue((v2.length === 3)
                ? [v2[0] + ox, v2[1] + oy, v2[2]]
                : [v2[0] + ox, v2[1] + oy]);
        }
    }

    function offsetProp1D(p, o) {
        if (p.numKeys > 0) {
            for (var k = 1; k <= p.numKeys; k++) {
                p.setValueAtKey(k, p.keyValue(k) + o);
            }
        } else {
            p.setValue(p.value + o);
        }
    }

    // 錨點移到圖層內容的 (fx, fy) 比例位置，並補償位置讓畫面不動
    function setAnchorGrid(fx, fy) {
        var comp = getComp();
        if (!comp) return;
        var layers = comp.selectedLayers;
        if (layers.length === 0) {
            alert("請先選取圖層。");
            return;
        }
        app.beginUndoGroup("KEYS Anchor");
        var skipped = [];
        try {
            for (var i = 0; i < layers.length; i++) {
                var ly = layers[i];
                if (!(ly instanceof AVLayer || ly instanceof ShapeLayer || ly instanceof TextLayer)) {
                    skipped.push(ly.name + "（非影像圖層）");
                    continue;
                }
                var ap = ly.transform.anchorPoint;
                if (ap.numKeys > 0) {
                    skipped.push(ly.name + "（錨點有關鍵影格）");
                    continue;
                }
                var r;
                try { r = ly.sourceRectAtTime(comp.time, false); }
                catch (eR) { skipped.push(ly.name + "（無法取得邊界）"); continue; }

                var oldA = ap.value;
                var newAx = r.left + r.width * fx;
                var newAy = r.top + r.height * fy;
                var dx = newAx - oldA[0];
                var dy = newAy - oldA[1];

                var sc = ly.transform.scale.value;
                var rotDeg = ly.threeDLayer
                    ? ly.transform.zRotation.value
                    : ly.transform.rotation.value;
                var th = rotDeg * Math.PI / 180;
                var vx = dx * sc[0] / 100;
                var vy = dy * sc[1] / 100;
                var ox = vx * Math.cos(th) - vy * Math.sin(th);
                var oy = vx * Math.sin(th) + vy * Math.cos(th);

                ap.setValue((oldA.length === 3) ? [newAx, newAy, oldA[2]] : [newAx, newAy]);

                var pos = ly.transform.position;
                if (pos.dimensionsSeparated) {
                    offsetProp1D(ly.transform.property("ADBE Position_0"), ox);
                    offsetProp1D(ly.transform.property("ADBE Position_1"), oy);
                } else {
                    offsetProp2D(pos, ox, oy);
                }
            }
        } catch (e) {
            alert("Anchor 失敗：" + e.toString());
        } finally {
            app.endUndoGroup();
        }
        if (skipped.length > 0) alert("以下圖層已跳過：\n" + skipped.join("\n"));
    }

    // ---------- Motion 風格自繪按鈕 ----------

    function makeToolButton(parent, opts) {
        // opts: {label, color, w, h, helpTip, onClickMod:function(mods)}
        var b = parent.add("iconbutton", undefined, undefined, { style: "toolbutton" });
        b.preferredSize = [opts.w || 100, opts.h || 34];
        b.helpTip = opts.helpTip || "";
        b._label = opts.label;
        b._color = opts.color;
        b._hover = false;

        b.onDraw = function () {
            var g = this.graphics;
            var w = this.size[0], h = this.size[1];
            var base = this._hover ? lighten(this._color, 0.12) : this._color;
            g.newPath();
            g.rectPath(0, 0, w, h);
            g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, base));
            // 底部深色細條，做出一點立體感
            g.newPath();
            g.rectPath(0, h - 2, w, 2);
            g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR,
                [base[0] * 0.6, base[1] * 0.6, base[2] * 0.6, 1]));
            var pen = g.newPen(g.PenType.SOLID_COLOR, COL.dark, 1);
            var sz;
            try { sz = g.measureString(this._label); } catch (eM) { sz = [w / 2, 12]; }
            g.drawString(this._label, pen,
                Math.max((w - sz[0]) / 2, 2),
                Math.max((h - sz[1]) / 2 - 1, 1),
                g.font);
        };
        b.addEventListener("mouseover", function () {
            this._hover = true;
            try { this.notify("onDraw"); } catch (e) {}
        });
        b.addEventListener("mouseout", function () {
            this._hover = false;
            try { this.notify("onDraw"); } catch (e) {}
        });
        b.onClick = function () {
            var mods = { alt: false, cmd: false, shift: false };
            try {
                var ks = ScriptUI.environment.keyboardState;
                mods.alt = ks.altKey;
                mods.cmd = ks.metaKey || ks.ctrlKey;
                mods.shift = ks.shiftKey;
            } catch (eM) {}
            opts.onClickMod(mods);
        };
        return b;
    }

    function paintText(st, colorArr) {
        try {
            st.graphics.foregroundColor =
                st.graphics.newPen(st.graphics.PenType.SOLID_COLOR, colorArr, 1);
        } catch (e) {}
    }

    // 曲線預設鈕：按鈕上直接畫出該預設的速度曲線（值-時間圖，兩端速度 0）
    function makeCurveButton(parent, opts) {
        // opts: {outInf, inInf, helpTip, onPick(outInf, inInf)}
        var b = parent.add("iconbutton", undefined, undefined, { style: "toolbutton" });
        b.preferredSize = [52, 34];
        b.helpTip = opts.helpTip;
        b._hover = false;
        b.onDraw = function () {
            var g = this.graphics;
            var w = this.size[0], h = this.size[1];
            var bg = this._hover ? [0.24, 0.24, 0.28, 1] : [0.15, 0.15, 0.18, 1];
            g.newPath();
            g.rectPath(0, 0, w, h);
            g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, bg));
            // 端點到端點的貝茲曲線，控制柄水平（速度0），長度=影響值
            var pad = 6;
            var x0 = pad, y0 = h - pad, x3 = w - pad, y3 = pad;
            var p1x = x0 + (x3 - x0) * opts.outInf / 100, p1y = y0;
            var p2x = x3 - (x3 - x0) * opts.inInf / 100, p2y = y3;
            var pen = g.newPen(g.PenType.SOLID_COLOR, COL.gold, 2);
            g.newPath();
            g.moveTo(x0, y0);
            var steps = 14;
            for (var s = 1; s <= steps; s++) {
                var t = s / steps, u = 1 - t;
                var px = u*u*u*x0 + 3*u*u*t*p1x + 3*u*t*t*p2x + t*t*t*x3;
                var py = u*u*u*y0 + 3*u*u*t*p1y + 3*u*t*t*p2y + t*t*t*y3;
                g.lineTo(px, py);
            }
            g.strokePath(pen);
        };
        b.addEventListener("mouseover", function () {
            this._hover = true;
            try { this.notify("onDraw"); } catch (e) {}
        });
        b.addEventListener("mouseout", function () {
            this._hover = false;
            try { this.notify("onDraw"); } catch (e) {}
        });
        b.onClick = function () {
            opts.onPick(opts.outInf, opts.inInf);
        };
        return b;
    }

    // 錨點九宮格鈕：按鈕上畫外框＋金點標示錨點位置
    function makeAnchorButton(parent, fx, fy, name) {
        var b = parent.add("iconbutton", undefined, undefined, { style: "toolbutton" });
        b.preferredSize = [30, 24];
        b.helpTip = "錨點移到「" + name + "」（畫面位置不變）";
        b._hover = false;
        b.onDraw = function () {
            var g = this.graphics;
            var w = this.size[0], h = this.size[1];
            var bg = this._hover ? [0.24, 0.24, 0.28, 1] : [0.15, 0.15, 0.18, 1];
            g.newPath();
            g.rectPath(0, 0, w, h);
            g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, bg));
            // 外框
            var framePen = g.newPen(g.PenType.SOLID_COLOR, [0.35, 0.35, 0.4, 1], 1);
            g.newPath();
            g.rectPath(4, 4, w - 8, h - 8);
            g.strokePath(framePen);
            // 錨點金點
            var dotR = 3;
            var cx = 4 + (w - 8) * fx, cy = 4 + (h - 8) * fy;
            g.newPath();
            g.ellipsePath(cx - dotR, cy - dotR, dotR * 2, dotR * 2);
            g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, COL.gold));
        };
        b.addEventListener("mouseover", function () {
            this._hover = true;
            try { this.notify("onDraw"); } catch (e) {}
        });
        b.addEventListener("mouseout", function () {
            this._hover = false;
            try { this.notify("onDraw"); } catch (e) {}
        });
        b.onClick = function () {
            setAnchorGrid(fx, fy);
        };
        return b;
    }

    // ---------- UI ----------

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", SCRIPT_NAME, undefined, { resizeable: true });

        try {
            win.graphics.backgroundColor =
                win.graphics.newBrush(win.graphics.BrushType.SOLID_COLOR, COL.bg);
        } catch (eBG) {}

        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 8;
        win.margins = 12;

        // --- 標題列 ---
        var head = win.add("group");
        head.orientation = "row";
        head.alignChildren = ["left", "center"];
        var title = head.add("statictext", undefined, "K E Y S");
        paintText(title, COL.gold);
        var ver = head.add("statictext", undefined, "v0.7");
        paintText(ver, COL.muted);

        // --- Ease 影響值 ---
        var rowInf = win.add("group");
        rowInf.orientation = "row";
        rowInf.alignChildren = ["left", "center"];
        var lblIn = rowInf.add("statictext", undefined, "進");
        paintText(lblIn, COL.text);
        var etIn = rowInf.add("edittext", undefined, "75");
        etIn.characters = 4;
        var lblOut = rowInf.add("statictext", undefined, "出");
        paintText(lblOut, COL.text);
        var etOut = rowInf.add("edittext", undefined, "75");
        etOut.characters = 4;
        var lblPct = rowInf.add("statictext", undefined, "%（0.1–100）");
        paintText(lblPct, COL.muted);

        function getInf() {
            var a = parseFloat(etIn.text), b = parseFloat(etOut.text);
            if (isNaN(a) || isNaN(b) || a < 0.1 || a > 100 || b < 0.1 || b > 100) {
                alert("影響值請輸入 0.1 ～ 100 的數字。");
                return null;
            }
            return [a, b];
        }

        // --- EASE 大鈕 ---
        makeToolButton(win, {
            label: "EASE 緩動",
            color: COL.ease,
            h: 40,
            helpTip: "點＝緩入緩出\n⌥ 點＝只緩入\n⌘ 點＝只緩出\n⇧ 點＝線性（清除緩動）",
            onClickMod: function (m) {
                if (m.shift) { applyEase("linear", 0, 0); return; }
                var v = getInf(); if (!v) return;
                if (m.alt) applyEase("in", v[0], v[1]);
                else if (m.cmd) applyEase("out", v[0], v[1]);
                else applyEase("both", v[0], v[1]);
            }
        });

        // --- CLONE / MIRROR ---
        var rowCM = win.add("group");
        rowCM.orientation = "row";
        rowCM.alignChildren = ["fill", "center"];
        rowCM.spacing = 8;
        makeToolButton(rowCM, {
            label: "CLONE 複製",
            color: COL.clone,
            w: 118, h: 36,
            helpTip: "點＝接續複製（貼到結尾後一格，連點=重複循環）\n⌥ 點＝鏡像接續：反轉接在後面，一鍵 ping-pong\n⌘ 點＝貼到時間指針（第一顆對齊指針）",
            onClickMod: function (m) {
                cloneKeys(m.alt ? "mirror" : (m.cmd ? "playhead" : "append"));
            }
        });
        makeToolButton(rowCM, {
            label: "MIRROR 鏡像",
            color: COL.mirror,
            w: 118, h: 36,
            helpTip: "選取範圍時間反轉（需 2 顆以上）：值序顛倒、緩動對調、路徑切線互換",
            onClickMod: function () { mirrorKeys(); }
        });

        // --- BOUNCE ---
        makeToolButton(win, {
            label: "BOUNCE 彈性",
            color: COL.bounce,
            h: 36,
            helpTip: "在最後一顆選取關鍵影格後，烘焙出衰減彈跳的真實關鍵影格（可再手調）\n點＝標準彈跳\n⌥ 點＝Q 彈（彈更多下）\n⇧ 點＝輕彈（過衝一下就停）\n※ 結尾要帶速度進來才彈得起來（結尾先點「線性」效果最明顯）",
            onClickMod: function (m) {
                if (m.alt) bounceKeys({ amp: 0.12, freq: 4, decay: 3.5 });
                else if (m.shift) bounceKeys({ amp: 0.05, freq: 2, decay: 9 });
                else bounceKeys({ amp: 0.08, freq: 2.5, decay: 5 });
            }
        });

        // --- VALUE 批量改值 ---
        var rowVal = win.add("group");
        rowVal.orientation = "row";
        rowVal.alignChildren = ["left", "center"];
        rowVal.spacing = 6;
        var lblVal = rowVal.add("statictext", undefined, "值");
        paintText(lblVal, COL.text);
        var etVal = rowVal.add("edittext", undefined, "10");
        etVal.characters = 5;
        makeToolButton(rowVal, {
            label: "VALUE 改值",
            color: COL.value,
            w: 150, h: 30,
            helpTip: "對選取的關鍵影格批量改值（N＝左邊欄位）\n點＝全部 +N（負數=減）\n⌥ 點＝全部 ×N（例 1.2＝放大 20%）\n⇧ 點＝每顆隨機 ±N（做抖動/不規則）",
            onClickMod: function (m) {
                var n = parseFloat(etVal.text);
                if (isNaN(n)) { alert("請在「值」欄輸入數字。"); return; }
                adjustKeyValues(m.alt ? "mul" : (m.shift ? "rand" : "add"), n);
            }
        });

        // --- SHIFT ---
        var rowSh = win.add("group");
        rowSh.orientation = "row";
        rowSh.alignChildren = ["fill", "center"];
        rowSh.spacing = 6;
        function shiftBtn(label, n) {
            makeToolButton(rowSh, {
                label: label,
                color: COL.shift,
                w: 56, h: 30,
                helpTip: "點＝移 " + Math.abs(n) + " 格\n⇧ 點＝移 " + Math.abs(n) * 10 + " 格",
                onClickMod: function (m) { shiftKeys(m.shift ? n * 10 : n); }
            });
        }
        shiftBtn("◀", -1);
        shiftBtn("▶", 1);

        // --- 曲線預設（點了套用並回填進/出數值） ---
        var lblCurve = win.add("statictext", undefined, "曲線預設");
        paintText(lblCurve, COL.muted);
        var rowCv = win.add("group");
        rowCv.orientation = "row";
        rowCv.alignChildren = ["fill", "center"];
        rowCv.spacing = 6;
        function pickCurve(outInf, inInf) {
            etOut.text = String(outInf);
            etIn.text = String(inInf);
            applyEase("both", inInf, outInf);
        }
        makeCurveButton(rowCv, { outInf: 33, inInf: 33,
            helpTip: "標準 33/33（同 AE Easy Ease）",
            onPick: pickCurve });
        makeCurveButton(rowCv, { outInf: 75, inInf: 75,
            helpTip: "柔順 75/75（進出都很黏）",
            onPick: pickCurve });
        makeCurveButton(rowCv, { outInf: 15, inInf: 85,
            helpTip: "急出緩收 15/85（爆衝出發、慢慢煞車）",
            onPick: pickCurve });
        makeCurveButton(rowCv, { outInf: 85, inInf: 15,
            helpTip: "緩出急收 85/15（慢慢啟動、瞬間到位）",
            onPick: pickCurve });

        // --- Anchor 九宮格 ---
        var lblAn = win.add("statictext", undefined, "錨點九宮格（畫面不動）");
        paintText(lblAn, COL.muted);
        var gridWrap = win.add("group");
        gridWrap.orientation = "column";
        gridWrap.alignChildren = ["left", "top"];
        gridWrap.spacing = 3;
        var anchorNames = [["左上", "中上", "右上"], ["左", "中心", "右"], ["左下", "中下", "右下"]];
        for (var gy = 0; gy < 3; gy++) {
            var rowAn = gridWrap.add("group");
            rowAn.orientation = "row";
            rowAn.spacing = 3;
            for (var gx = 0; gx < 3; gx++) {
                makeAnchorButton(rowAn, gx / 2, gy / 2, anchorNames[gy][gx]);
            }
        }

        // --- 轉場 ---
        var lblTr = win.add("statictext", undefined, "轉場（選圖層，從指針開始烘焙）");
        paintText(lblTr, COL.muted);
        var rowTr = win.add("group");
        rowTr.orientation = "row";
        rowTr.alignChildren = ["left", "center"];
        rowTr.spacing = 6;
        var lblTrF = rowTr.add("statictext", undefined, "格數");
        paintText(lblTrF, COL.text);
        var etTrF = rowTr.add("edittext", undefined, "12");
        etTrF.characters = 3;

        function getTrFrames() {
            var n = parseFloat(etTrF.text);
            if (isNaN(n) || n < 2) { alert("格數請輸入 2 以上的數字。"); return null; }
            return n;
        }
        makeToolButton(rowTr, {
            label: "閃",
            color: COL.trans,
            w: 62, h: 28,
            helpTip: "爆閃轉場（HOLD 硬切，掛不透明度）\n點＝瞬閃亮起（閃入）\n⌥ 點＝瞬閃消失（閃出）",
            onClickMod: function (m) {
                var n = getTrFrames(); if (!n) return;
                transFlash(!m.alt, n);
            }
        });
        makeToolButton(rowTr, {
            label: "淡",
            color: COL.trans,
            w: 62, h: 28,
            helpTip: "淡入淡出（掛不透明度）\n點＝淡入\n⌥ 點＝淡出",
            onClickMod: function (m) {
                var n = getTrFrames(); if (!n) return;
                transFade(!m.alt, n);
            }
        });
        makeToolButton(rowTr, {
            label: "彈",
            color: COL.trans,
            w: 62, h: 28,
            helpTip: "縮放彈跳（掛縮放，含 8% 過衝）\n點＝彈入（0→108%→100）\n⌥ 點＝彈出（100→108%→0）",
            onClickMod: function (m) {
                var n = getTrFrames(); if (!n) return;
                transPop(!m.alt, n);
            }
        });

        // --- 快速表達式 ---
        var lblEx = win.add("statictext", undefined, "快速表達式（選屬性直接掛，免關鍵影格）");
        paintText(lblEx, COL.muted);
        var rowExP = win.add("group");
        rowExP.orientation = "row";
        rowExP.alignChildren = ["left", "center"];
        var lblF = rowExP.add("statictext", undefined, "頻率");
        paintText(lblF, COL.text);
        var etF = rowExP.add("edittext", undefined, "2");
        etF.characters = 4;
        var lblA = rowExP.add("statictext", undefined, "幅度");
        paintText(lblA, COL.text);
        var etA = rowExP.add("edittext", undefined, "30");
        etA.characters = 4;

        function getFA() {
            var f = parseFloat(etF.text), a = parseFloat(etA.text);
            if (isNaN(f) || isNaN(a)) { alert("頻率與幅度請輸入數字。"); return null; }
            return [f, a];
        }

        var rowEx1 = win.add("group");
        rowEx1.orientation = "row";
        rowEx1.spacing = 6;
        makeToolButton(rowEx1, {
            label: "抖動",
            color: COL.expr,
            w: 76, h: 28,
            helpTip: "wiggle(頻率, 幅度)\n位置=手持感、鏡頭晃；亮度=閃爍霓虹\n任何屬性都能掛",
            onClickMod: function () {
                var v = getFA(); if (!v) return;
                setExpr("wiggle(" + v[0] + ", " + v[1] + ");", "KEYS 抖動");
            }
        });
        makeToolButton(rowEx1, {
            label: "閃爍",
            color: COL.expr,
            w: 76, h: 28,
            helpTip: "掛在不透明度上\n點＝規律開關閃（頻率=每秒次數）\n⌥ 點＝隨機閃（壞掉的日光燈/霓虹感）",
            onClickMod: function (m) {
                var v = getFA(); if (!v) return;
                if (m.alt) {
                    setExpr("posterizeTime(" + v[0] + ");\nrandom() < 0.5 ? value : value*0;", "KEYS 隨機閃爍");
                } else {
                    setExpr("Math.floor(time*" + v[0] + "*2)%2==0 ? value : value*0;", "KEYS 規律閃爍");
                }
            }
        });
        makeToolButton(rowEx1, {
            label: "自轉",
            color: COL.expr,
            w: 76, h: 28,
            helpTip: "掛在旋轉上：等速自轉\n幅度＝每秒轉幾度（360=每秒一圈，負數反轉）",
            onClickMod: function () {
                var v = getFA(); if (!v) return;
                setExpr("value + time*" + v[1] + ";", "KEYS 自轉");
            }
        });

        var rowEx2 = win.add("group");
        rowEx2.orientation = "row";
        rowEx2.spacing = 6;
        makeToolButton(rowEx2, {
            label: "循環",
            color: COL.expr,
            w: 76, h: 28,
            helpTip: "讓現有關鍵影格動畫無限循環\n點＝cycle 從頭重播\n⌥ 點＝pingpong 來回\n⌘ 點＝offset 累加延續（走位不斷往前）",
            onClickMod: function (m) {
                var mode = m.alt ? "pingpong" : (m.cmd ? "offset" : "cycle");
                setExpr('loopOut("' + mode + '");', "KEYS 循環");
            }
        });
        makeToolButton(rowEx2, {
            label: "呼吸",
            color: COL.expr,
            w: 76, h: 28,
            helpTip: "正弦律動：value ×(1±幅度%)\n掛縮放=呼吸感、掛不透明度=柔和明滅\n頻率=每秒次數，幅度=百分比",
            onClickMod: function () {
                var v = getFA(); if (!v) return;
                setExpr("value * (1 + Math.sin(time*" + v[0] + "*2*Math.PI)*" + v[1] + "/100);", "KEYS 呼吸");
            }
        });
        makeToolButton(rowEx2, {
            label: "清除",
            color: [0.42, 0.42, 0.48, 1],
            w: 76, h: 28,
            helpTip: "移除選取屬性上的表達式",
            onClickMod: function () {
                setExpr("", "KEYS 清除表達式");
            }
        });

        var hint = win.add("statictext", undefined,
            "滑鼠停按鈕看修飾鍵用法｜面板聚焦時 ←→ 移格（⇧=10）", { multiline: true });
        paintText(hint, COL.muted);
        hint.alignment = ["fill", "top"];

        // --- 方向鍵平移（輸入框內留給游標） ---
        function onKey(e) {
            try {
                if (e.target && e.target.type === "edittext") return;
                var shift = false;
                try { shift = e.getModifierState("Shift"); } catch (eM) {}
                if (e.keyName === "Left") shiftKeys(shift ? -10 : -1);
                else if (e.keyName === "Right") shiftKeys(shift ? 10 : 1);
            } catch (eK) {}
        }
        win.addEventListener("keydown", onKey);

        win.layout.layout(true);
        win.onResizing = win.onResize = function () { this.layout.resize(); };

        if (win instanceof Window) {
            win.center();
            win.show();
        }
        return win;
    }

    buildUI(thisObj);

})(this);
